using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Website.App.Security;

namespace Website.Pages.Home.Endpoints
{
    [IgnoreAntiforgeryToken]
    public class NotificationCheckModel : PageModel
    {
        public IActionResult OnGet() => NotFound();
        public IActionResult OnPost()
        {
            if (!User.IsAuthorised())
                return new JsonResult(new { ok = false, msg = "Unauthorized" }) { StatusCode = StatusCodes.Status401Unauthorized };

            try
            {
                string sql = $"SELECT COUNT(*) FROM msg.notification WHERE recipient_user_id = {User.Id()} AND is_read = false;";
                long affected = Convert.ToInt64(App.Database.DataAccessManager.ExecuteScalar("msg", sql, []));
                return new JsonResult(new { ok = affected > 0, newCount = affected });
            }
            catch (Exception ex)
            {
                return new JsonResult(new { ok = false, msg = ex.Message });
            }
        }
    }

}
