﻿using System.Text;
using System.Text.RegularExpressions;

namespace Website.App.StringBuilders
{
    public static partial class SiteCSS
    {
        [GeneratedRegex(@"\s+", RegexOptions.Compiled)]
        private static partial Regex MyRegex();
        public static void Create()
        {
            // Get the minified CSS string from SiteCSS
            // The path will always be wwwwroot/css/site.css
            string path = Path.Combine("wwwroot", "css", "site.css");
            if (File.Exists(path)) File.Delete(path);

            string cssContent = SiteCSS.Get();
            File.WriteAllText(path, cssContent);
        }
        private static string Get()
        {
            StringBuilder sb = new();
            sb.Append(Base.Get());
            sb.Append(Layout.Get());
            sb.Append(Elements.Get());
            sb.AppendLine(Address());

            return Minify(sb.ToString());
        }
        private static string Minify(string CSS)
        {
            string minified = CSS.Replace("\r", "").Replace("\n", "").Replace("\t", "").Replace("  ", "");

            return MyRegex().Replace(minified, " ").Trim();
        }
        private static class Base
        {
            internal static string Get()
            {
                StringBuilder sb = new();
                sb.AppendLine(Theme());
                sb.AppendLine(DarkMode());
                sb.AppendLine(Generic());
                sb.AppendLine(BaseElements());
                return sb.ToString();
            }
            private static string Theme()
            {

                string css = @"
            :root {
            --font-family-base: 'Font Awesome 7 Free', system-ui, -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            --color-primary: #ff5a5f;
            --color-primary-hover: #e14b50;
            --color-secondary: #007bff;
            --color-text: #333333;
            --btn-primary-bg: #ff5a5f;
            --btn-primary-hover-bg: #e14b50;
            --btn-primary-hover-text: #0;             
            --btn-primary-text: #ffffff; 
            --btn-secondary-bg: #dc3545;
            --btn-secondary-hover-bg: #c82333;
            --btn-secondary-text: #fff;
            --btn-transparent-bg: transparent;
            --btn-transparent-border: #ff5a5f;
            --btn-transparent-text: #ff5a5f;
            --btn-transparent-hover-bg: #ff5a5f;
            --btn-transparent-hover-text: #ffffff;
            --color-bg: #ffffff;
            --color-bg-alt: #f9f9f9;
            --color-bg-alt-alt: #f0f0f0;
            --shadow-light: rgba(0,0,0,0.1);
            --shadow-strong: rgba(0,0,0,0.15);
            --hero-overlay-start: rgba(0,0,0,0.5);
            --hero-overlay-end: rgba(0,0,0,0.3);
            --input-height-mobile: 2.5rem;
            --input-height-tablet: 2.75rem;
            --input-height-desktop: 3rem;
            --top-bar-height: 3.5rem;
            --pill-bar-height: 2.5rem;
            --dash-header-height: calc(var(--top-bar-height)+var(--pill-bar-height));
            --dash-footer-height: 3.5rem;
            --spacing-small: .5rem;
            --spacing-medium: 1rem;
            --spacing-large: 2rem;
            --radius-medium: 0.5rem;
        }
            h1 { font-size: clamp(1.5rem, 4vw + 1rem, 3rem); }
            h2 { font-size: clamp(1.25rem, 3.5vw + 1rem, 2.5rem); }
            h3 { font-size: clamp(1.125rem, 3vw + 1rem, 2rem); }
            h4 { font-size: clamp(1rem, 2.5vw + 1rem, 1.75rem); }
            h5 { font-size: clamp(0.875rem, 2vw + 0.875rem, 1.5rem); }
            h6 { font-size: clamp(0.75rem, 1.5vw + 0.75rem, 1.25rem); }";
                return css;
            }
            private static string DarkMode()
            {
                string css = @"@media(prefers-color-scheme: dark) {
            :root {
            --color-text: #e1e1e1;
            --color-bg: #121212;
            --color-bg-alt: #1a1a1a;
            --color-bg-alt-alt: #222222;
            --color-header-bg: #1f1f1f;
            --color-footer-bg: #1a1a1a;
            }}";
                return css;
            }
            private static string Generic()
            {
                string css = @".nav-group { display: inline-flex; align-items: center; justify-content: flex-end; gap: 1rem; font-family: var(--font-family-base); }
                .spinner { width: 3rem; height: 3rem; border: 4px solid rgba(255, 255, 255, 0.3); border-top-color: var(--color-primary); border-radius: 50%; animation: spin 1s linear infinite; } 
                .spinner--sm { width: .9em; height: .9em; border-width: .12em; }
                .spinner--md { width: 1.25em; height: 1.25em; }
                .spinner--lg { width: 2rem; height: 2rem; }
                .spinner-overlay { position: fixed; inset: 0; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,.35); z-index: 9999; }
                .spinner-overlay[hidden] { display: none; }
                @keyframes spin { to { transform: rotate(360deg); }} 
                .error-msg { color: var(--color-primary); font-size: 0.9rem; margin-top: 0.25rem; display: block; }";
                return css;
            }
            private static string BaseElements()
            {
                string css = @"
            html, body { margin: 0; padding: 0; font-family: var(--font-family-base); font-size: clamp(0.55rem, 0.5vw + 0.55rem, 1.25rem); line-height: 1.5; color: var(--color-text); background-color: var(--color-bg); display: flex; flex-direction: column; height: 100vh; overflow: hidden; }
            *, *::before, *::after { box-sizing: border-box; }

            button, input, select, textarea { font-family: inherit; }

            a { 
            font-family: var(--font-family-base);
            color: var(--color-text);
            text-decoration: none;
            font-size: clamp(0.55rem, 0.5vw + 0.55rem, 1.25rem); 
            }
                a:hover { color: var(--color-primary-hover); }
            a.nav {
                font-weight: 500;
                color: var(--color-text);
                text-decoration: none;
                display: inline-block;
                padding: 0.25rem 0.75rem;
                line-height: 1.3;
                transition: color 0.2s ease;
            }
            a.nav:hover,
            a.nav:focus { color: var(--color-primary); }

            button { cursor: pointer; }

            input[type=""text""], input[type=""email""], input[type=""number""], input[type=""password""],
            textarea, select { 
            font-family: var(--font-family-base); font-size: clamp(0.55rem, 0.5vw + 0.55rem, 1.25rem);
            line-height: 1.5; color: var(--color-text); background-color: var(--color-bg-alt); border: 1px solid var(--color-primary);
            border-radius: var(--radius-medium); padding: 0.75rem 1rem; width: 100%; box-sizing: border-box;
            transition: border-color 0.3s ease, box-shadow 0.3s ease; outline: none; }

            input[disabled], textarea[disabled], select[disabled] {
            opacity: 0.6; cursor: not-allowed; background-color: var(--color-bg-alt-alt); }

            label { display: block; font-weight: 500; margin-bottom: 0.25rem; color: var(--color-text); }

            select { appearance: none; background-repeat: no-repeat; background-position: right 1rem center; background-size: 1rem; }
            ";
                return css;
            }
        }
        private static class Layout
        {
            internal static string Get()
            {
                StringBuilder sb = new();
                sb.AppendLine(MainContainer());
                sb.AppendLine(Footer());

                return sb.ToString();
            }
            private static string MainContainer()
            {
                string css = @".site-main {overflow-y: auto; width: 100%; margin: 0 auto;}";
                return css;
            }
            private static string Footer()
            {
                string css = @"
                .site-footer {
                display: flex;
                flex-wrap: wrap;
                align-items: center;
                justify-content: center;
                gap: 0.5rem;}

                .footer-container {
                display: flex; flex-wrap: wrap; align-items: center; justify-content: center; gap: 0.5rem;
                width: 90%; margin: 0 auto; padding: .15rem 1rem;
                text-align: center; font-size: clamp(0.55rem, 0.5vw + 0.55rem, 1.25rem);}";

                return css;
            }
        }
        private static class Elements
        {
            internal static string Get()
            {
                StringBuilder sb = new();
                sb.AppendLine(Buttons())
                .AppendLine(Inputs())
                .AppendLine(GridCanvasCards())
                .AppendLine(CustomModals())
                .AppendLine(Password())
                .AppendLine(MapBox())
                .AppendLine(SideMenu());

                return sb.ToString();
            }
            private static string Buttons()
            {
                //<button class="btn btn-primary">Home</button>
                //<button class="btn btn-nav btn-outline">Settings</button>
                //<button class="btn btn-pill btn-transparent">Logout</button>
                //<button cursor:pointer - set in BaseElements
                string css = @".btn {display: inline-flex; align-items: center; justify-content: center; padding: 0.75rem 1.5rem; border-radius: 30px; border: none; font-weight: 600; font-size: clamp(0.55rem, 0.5vw + 0.55rem, 1.25rem); transition: all 0.3s ease; box-shadow: 0 4px 6px var(--shadow-light);}
                .btn-close { display: inline-flex; align-items: center; justify-content: center; width: 2.5rem; height: 2.5rem; border-radius: 50%; background-color: var(--btn-secondary-hover-bg); color: var(--btn-secondary-text); border: none; font-size: 1.55rem; transition: all 0.2s ease; }
                .btn-primary {background: var(--btn-primary-bg); color: var(--btn-primary-text); }
                .btn-primary:hover {background: var(--btn-primary-hover-bg); color: var(--btn-primary-hover-text); transform: translateY(-2px); box-shadow: 0 6px 8px var(--shadow-strong); }
            
                .btn-outline {background: var(--btn-transparent-bg); color: var(--color-text); border: 2px solid var(--color-text); }
                .btn-outline:hover {background: background: rgba(0,0,0,0.05); var(--color-primary); border-color: var(--color-primary); }
            
                .btn-secondary {background: var(--btn-secondary-bg); color: var(--btn-secondary-text); border: 2px solid var(--btn-transparent-border); }
                .btn-secondary:hover {background: var(--btn-secondary-hover-bg); color: var(--btn-secondary-text); transform: translateY(-2px); }
            
                .btn-nav {padding: 0.35rem 0.9rem; border-radius: 15px; box-shadow: none; line-height: 1.2; }
                .btn-nav:hover {transform: translateY(-1px); box-shadow: none; }
                .btn-pill {padding: 0.35rem 0.9rem; font-size: clamp(0.55rem, 0.5vw + 0.55rem, 1.25rem); white-space: nowrap; border-radius: 9999px; box-shadow: 0 2px 4px var(--shadow-light); line-height: 1.2; }
                .btn-pill:hover {transform: translateY(-1px); box-shadow: 0 4px 6px var(--shadow-strong); }
                .btn-pill-disabled {opacity: .5; pointer-events: none; }";

                return css;
            }
            private static string Inputs()
            {
                string css = @"input:focus, textarea:focus, select:focus { border-color: var(--color-primary-hover); box-shadow: 0 0 0 3px rgba(255, 90, 95, 0.2); }
                select.input-text {
                appearance: none;
                background-color: var(--color-bg-alt);
                background-image: url('/assets/icons/fa-chevron-down.svg');
                background-repeat: no-repeat;
                background-position: right 1rem center;
                background-size: 1rem;
                color: var(--color-text);
                border: 1px solid var(--color-primary);
                border-radius: 8px;
                padding: 0.75rem 2.5rem 0.75rem 1rem;
                width: 100%;
                box-sizing: border-box;
                font-family: inherit;
                font-size: 1rem;
                transition: border-color 0.25s ease, box-shadow 0.25s ease; }

                select.input-text {
                    appearance: none;
                    background-color: var(--color-bg-alt);
                    background-image: url(""data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><path fill='%23888888' d='M201.4 406.6c12.5 12.5 32.8 12.5 45.3 0l192-192c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L224 338.7 54.6 169.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l192 192z'/></svg>"");
                    background-repeat: no-repeat;
                    background-position: right 1rem center;
                    background-size: 1rem;
                    padding-right: 2rem; /* make room for the icon */
                    cursor: pointer;
                }
                select.input-text:focus { outline: none; border-color: var(--color-accent); box-shadow: 0 0 0 2px var(--color-accent-fade); }
                select.input-text:disabled { opacity: 0.6; cursor: not-allowed; }";

                return css;
            }
            private static string GridCanvasCards()
            {
                string css = @".grid-canvas {width: 100%; max-height: 100%; background-color: var(--color-bg-alt); padding: var(--spacing-medium);}
                .grid {display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: var(--spacing-medium); align-items: stretch; width: 100%}
                .card {background-color: var(--color-bg-alt-alt); border: 2px solid var(--color-primary); border-radius: var(--radius-medium); box-shadow: 0 2px 4px var(--shadow-light); display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 1rem; gap: 0.5rem; box-sizing: border-box;}
                .card h3 {margin: 0 0 0.5rem 0; font-weight: 600; font-size: clamp(0.55rem, 0.5vw + 0.55rem, 1.25rem);; text-align: center;}
                .card p, .card b, .card i, .card ul, .card blockquote {margin: 0; text-align: center;}";

                return css;
            }
            private static string CustomModals()
            {
                string css = @".custom-modal { display: none; position: fixed; inset: 0; z-index: 10000; background-color: rgba(0, 0, 0, 0.8); overflow-y: auto; overflow-x: hidden; }
                .custom-modal.hidden { display: none; } 
                .custom-modal.show { display: flex; align-items: center; justify-content: center; }
                .custom-modal-content { opacity: 1; background-color: var(--color-bg-alt); color: var(--color-text); width: 90%; max-width: 700px; margin: 2rem auto; padding: 1rem; border-radius: 0.5rem; border: 2px solid var(--color-primary); background-color: var(--color-bg-alt); box-shadow: var(--theme-box-shadow); overflow-y: auto; height: 80vh; display: flex; flex-direction: column; }
                @media (max-width: 992px) { .custom-modal-content { max-width: 500px; } }
                @media (max-width: 768px) { .custom-modal-content { max-width: 90%; } }
                @media (max-width: 480px) { .custom-modal-content { max-width: 95%; } }
                .custom-modal-body { display: flex; flex-direction: column; gap: 0.5rem; }
                .custom-modal-header { display: flex; justify-content: space-between; align-items: center; padding: 0.5rem 1rem; }
                .custom-modal-header h5 { margin: 0; font-size: 1rem; flex: 1; color: var(--color-on-primary);}";

                return css;
            }
            private static string Password()
            {
                string css = @".password-wrapper { position: relative; width: 100%; }
                .password-wrapper .input-text { width: 100%; padding-right: 2.5rem; }
                .password-toggle { position: absolute;
                top: 65%;
                right: 0.5rem;
                transform: translateY(-50%);
                background: none;
                border: none;
                font-size: 2rem;
                color: var(--color-primary);
                cursor: pointer;
                padding: 0;
                line-height: 1;
                z-index: 10;
                opacity: 0.9;
                filter: drop-shadow(0 1px 1px rgba(0, 0, 0, 0.4));
                transition: color 0.2s ease, opacity 0.2s ease; }
                .password-toggle:hover { color: var(--color-text); }
                input[type=""password""]::-ms-reveal, input[type=""password""]::-webkit-credentials-auto-fill-button { display: none !important; }";

                return css;
            }
            private static string MapBox()
            {
                string css = @".mapbox-address-autofill { position: relative; display: block; width: 100%; font-size: 1rem; padding: 0.75rem 1rem; box-sizing: border-box; border: 1px solid var(--color-primary); border-radius: 8px; background-color: var(--color-bg-alt); color: var(--color-text); }
                .mapbox-address-autofill input { width: 100%; padding: 0.75rem 1rem; font-size: 1rem; font-family: inherit; box-sizing: border-box; border: none; outline: none; background: transparent; color: var(--color-text); }
                .mapbox-address-autofill:focus-within { border-color: var(--color-primary); box-shadow: 0 0 0 2px rgba(255, 90, 95, 0.2); }
                .mapbox-address-autofill ul { position: absolute; top: 100%; left: 0; width: 100%; max-height: 200px; overflow-y: auto; margin: 0; padding: 0; list-style: none; background-color: var(--color-bg-alt); border-left: 1px solid var(--color-primary); border-right: 1px solid var(--color-primary); border-bottom: 1px solid var(--color-primary); border-top: none; border-radius: 0 0 8px 8px; z-index: 1000; box-shadow: 0 2px 8px rgba(0,0,0,0.15); color: var(--color-text); }
                .mapbox-address-autofill ul li { padding: 0.5rem 1rem; cursor: pointer; background-color: var(--color-bg-alt); }
                .mapbox-address-autofill ul li:hover, .mapbox-address-autofill ul li.selected { background-color: var(--color-primary); color: var(--color-text); }";

                return css;
            }
            private static string SideMenu()
            {
                string css = @".side-menu { position: fixed; top: var(--top-bar-height); bottom: 0; left: -280px; width: 280px; background: var(--color-bg-alt); box-shadow: 2px 0 8px rgba(0,0,0,.2); transition: left .3s ease; z-index: 1001; padding-top: var(--spacing-medium); }
                body.menu-open .side-menu { left: 0; }
                .menu-backdrop { position: fixed; inset: 0; background: rgba(0,0,0,.45); opacity: 0; pointer-events: none; transition: opacity .2s ease; z-index: 1000; }
                body.menu-open .menu-backdrop { opacity: 1; pointer-events: auto; }
                body.menu-open { overflow: hidden; }
                .side-menu ul { margin: 0; padding: 0; list-style: none; }
                .side-menu li { margin: var(--spacing-small) 0; }
                .side-menu a { display: flex; align-items: center; padding: .75rem 1rem; text-decoration: none; color: var(--color-text); }
                .side-menu a i { width: 1.25rem; text-align: center; margin-right: .75rem; }
                .side-menu a:hover { background: rgba(255,255,255,.1); }";

                return css;
            }
        }
        private static string Address()
        {
            string css = @".address-card { padding: var(--spacing-medium); border: 2px solid var(--color-primary); border-radius: 16px; display: block; }
            .address-option-row { display: grid; grid-template-columns: auto 1fr; align-items: center; column-gap: .5rem; }
            .address-line { font-size: .85rem; color: var(--color-text-secondary); margin-top: .25rem;}            
            .address-radio { margin: 0; inline-size: 1em; block-size: 1em; transform: scale(1.1); }
            .address-label { font-size: .95rem; font-weight: 600; cursor: pointer; word-break: break-word;}";

            return css;
        }
    }
}